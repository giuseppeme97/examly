#from dotenv import load_dotenv
import os

#load_dotenv()
# UPLOADED = os.getenv("UPLOADED")
UPLOADED = "./uploaded"
TEMPLATE = os.getenv("TEMPLATE")